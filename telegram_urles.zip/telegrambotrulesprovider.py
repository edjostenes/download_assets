import json
import operator
from datetime import date, datetime
from sqlalchemy import func
from sqlalchemy import or_

from business.base import Base
from business.telegrambotrules import TelegramBotRules
import config as cfg

class TelegramBotRulesProvider:
    def __init__(self, session, redis):
        self.Session = session

    def upsert(self, objectData):
        try:
            result = None
            session = self.Session()
            query = session.query(TelegramBotRules).filter_by(idCompetition=objectData.idCompetition)
            if(objectData.idBotTelegramRules is not None):                
                query = query.filter_by(idBotTelegramRules=objectData.idBotTelegramRules)
                encontrado = query.first()
            else:
                encontrado = None

            if(encontrado is None):
                result = self.insert(objectData)
            else:
                encontrado.numeroGols = objectData.numeroGols
                encontrado.mercadoEntrada = objectData.mercadoEntrada
                encontrado.valueUnder25 = objectData.valueUnder25
                encontrado.valueOver15 = objectData.valueOver15
                encontrado.valueOver25 = objectData.valueOver25
                encontrado.valueAmbasMarcam = objectData.valueAmbasMarcam
                result = objectData  
                session.commit()   
        except Exception as ex:
            print('ex: ' + str(ex))
            raise ex
        finally:
            session.close() 
            return result

    def insert(self, objectData):
        try:
            result = False
            session = self.Session()
            session.add(objectData)
            session.flush()   
            result = objectData     
            session.commit()   
        except Exception as ex:
            print('Falha ao inserir: ' + str(ex))
            raise ex
        finally:
            session.close() 
            return result

    def delete(self, idBotTelegramRules):
        try:
            result = False
            session = self.Session()
            result = session.query(TelegramBotRules)\
                        .filter_by(idBotTelegramRules=idBotTelegramRules).delete()
            session.commit()   
        except Exception as ex:
            print('Falha ao inserir: ' + str(ex))
            raise ex
        finally:
            session.close() 
            return result

    def getRulesByCompetition(self, idCompetition):
        try:
            session = self.Session()
            return session.query(TelegramBotRules)\
                .filter(TelegramBotRules.idCompetition == idCompetition).all()
        finally:
            session.close()          

