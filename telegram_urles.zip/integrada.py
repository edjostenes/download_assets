import math
import json
import redis
import random
from datetime import datetime
import config as cfg
from api import common as cmn
from flask import Flask, jsonify, request, abort
from flask import request as freq
from flask_restplus import Namespace, Resource, fields
from api import baseapi
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from business.telegrambotrules import TelegramBotRules 
from provider.matchdataprovider import MatchDataProvider
from provider.competitionprovider import CompetitionProvider
from provider.sportprovider import SportProvider
from provider.userprovider import UserProvider
from provider.adversaryprovider import AdversaryProvider
from provider.statisticsprovicer import StatisticsProvider
from provider.overprovider import OverProvider
from provider.oddsprovider import OddsProvider
from provider.telegrambotrulesprovider import TelegramBotRulesProvider

api = Namespace('', description='Operações relacionadas a API')

#redis
redis_url = "redis://h:pf11e416ace83a3daabe65401598e512abc0cea313b95284529fbed34ee786d55@ec2-34-198-22-64.compute-1.amazonaws.com:18329"
r = redis.StrictRedis.from_url(redis_url, decode_responses=True)
#r.flushdb()

#sql alchemy connection
engine = create_engine(cfg.conexao_banco_ativa['mysql_conn'],
                       pool_size=40,
                       max_overflow=0,
                       pool_recycle=3600,
                       connect_args={'connect_timeout': 60})
Session = sessionmaker(bind=engine)

adversaryProvider = AdversaryProvider(Session, r)
matchDataProvider = MatchDataProvider(Session, r)
competitionProvider = CompetitionProvider(Session, r)
sportProvider = SportProvider(Session, r)
userProvider = UserProvider(Session, r)
statisticsProvider = StatisticsProvider(matchDataProvider, r)
overProvider = OverProvider(Session, r)
oddsProvider = OddsProvider(Session, r)
telegramRulesProvider = TelegramBotRulesProvider(Session, r)

def validate_token(func):
    def wrapper(*args, **kwargs):
        if not _isValidToken(request.headers):
            _getJsonGenericError(400, 'Não autorizado', 'Verifique seus dados de acesso')

        return func(*args, **kwargs)
    return wrapper

def _getJsonGenericError(errorCode, errorMessage, detailsMessage):
    return api.abort(errorCode, errorMessage, details = detailsMessage, success = False)

def _getJsonError(errorMessage, details):
    return jsonify({'success':False, 'message':errorMessage, 'details':details})

def _getJsonSuccess(jsonData):
    data = {'success':True}
    data.update(jsonData)
    return jsonify(data)

def _getProperty(propertyName, defaultValue=None):
    if propertyName in request.form:
        return request.form.get(propertyName)
    return defaultValue

def _isValidToken(headers):
    token = headers.get("X-Api-Key")

    if (token is None):
        return False
    
    return userProvider.isValidToken(token)

@api.doc(
    params=
    {
        'idCompetition': 'Id da competição'
    }
)
@api.route('/getTelegramRules', methods=['POST'])
class getTelegramRules(Resource):
    @validate_token
    def post(self):
        try:
            idCompetition = _getProperty('idCompetition', defaultValue=None)

            if (idCompetition == None):
                return _getJsonError('Informe o idCompetition', 'Verifique o parâmetro idCompetition')

            competitionJson = competitionProvider.getCompetitionById(idCompetition)
            telegramRules = telegramRulesProvider.getRulesByCompetition(idCompetition)
            return _getJsonSuccess(
                {
                    'rules': cmn.mountObjectClean(telegramRules) if telegramRules is not None else [],
                    'competition': competitionJson if competitionJson is not None else ""
                }
            )
        except Exception as e:
            _getJsonGenericError(500, '[getTelegramRules] Erro desconhecido', str(e))

@api.doc(
    params=
    {
        'idBotTelegramRules': 'ID chave da mensagem do telegram. Se não for passado será criado um novo registro,',
        'mercadoEntrada': 'Texto de principal para a mensagem do telegram',
        'numeroGols': 'Texto complementar para a mensagem do telegram',
        'valueUnder25': 'valor base para a regrar do under 2.5 (porcentagem)',
        'valueOver15': 'valor base para a regrar do over 1.5 (porcentagem)',
        'valueOver25': 'valor base para a regrar do over 2.5 (porcentagem)',
        'valueAmbasMarcam': 'valor base para a regrar do ambas marcam (porcentagem)',        
        'idCompetition': 'Id da competição'
    }
)
@api.route('/upsertTelegramRules', methods=['POST'])
class getTelegramRules(Resource):
    @validate_token
    def post(self):
        try:
            idBotTelegramRules = _getProperty('idBotTelegramRules', defaultValue=None)
            mercadoEntrada = _getProperty('mercadoEntrada', defaultValue=None)
            numeroGols = _getProperty('numeroGols', defaultValue=None)
            valueUnder25 = _getProperty('valueUnder25', defaultValue=None)
            valueOver15 = _getProperty('valueOver15', defaultValue=None)
            valueOver25 = _getProperty('valueOver25', defaultValue=None)
            valueAmbasMarcam = _getProperty('valueAmbasMarcam', defaultValue=None)
            idCompetition = _getProperty('idCompetition', defaultValue=None)

            if (idCompetition == None):
                return _getJsonError('Informe o idCompetition', 'Verifique o parâmetro idCompetition')

            competitionJson = competitionProvider.getCompetitionById(idCompetition)

            rule = TelegramBotRules()
            if(idBotTelegramRules is not None):
                rule.idBotTelegramRules = idBotTelegramRules
            rule.mercadoEntrada = mercadoEntrada
            rule.numeroGols = numeroGols
            rule.valueUnder25 = valueUnder25
            rule.valueOver15 = valueOver15
            rule.valueOver25 = valueOver25
            rule.valueAmbasMarcam = valueAmbasMarcam
            rule.idCompetition = idCompetition
            telegramRule = telegramRulesProvider.upsert(rule)

            #RETORNA O REGISTRO CRIADO. INFORMAR SE SUCESSO OU NAO
            return _getJsonSuccess(
                {

                }
            )
        except Exception as e:
            _getJsonGenericError(500, '[getTelegramRules] Erro desconhecido', str(e))

@api.doc(
    params=
    {
        'idBotTelegramRules': 'ID chave da mensagem do telegram'
    }
)
@api.route('/deleteTelegramRule', methods=['POST'])
class deleteTelegramRule(Resource):
    @validate_token
    def post(self):
        try:
            idBotTelegramRules = _getProperty('idBotTelegramRules', defaultValue=None)
            if(idBotTelegramRules == None):
                return _getJsonError('Informe o idBotTelegramRules', 'Verifique o parâmetro idBotTelegramRules')

            result = telegramRulesProvider.delete(idBotTelegramRules)
            if(not result):
                raise Exception('Registro não encontrado.')
            return _getJsonSuccess({})
        except Exception as e:
            _getJsonGenericError(500, '[getTelegramRules] Erro desconhecido', str(e))
