# coding=utf-8
import datetime
from sqlalchemy import Column, String, Integer, Date, Text, Boolean
from sqlalchemy import Numeric, Sequence, CHAR, DateTime, UniqueConstraint, ForeignKey
from business.base import Base
from business.competition import Competition

class TelegramBotRules(Base):
    __tablename__ = 'TelegramBotRules'

    idBotTelegramRules = Column(Integer, primary_key=True)
    mercadoEntrada = Column(String(150), nullable=False)
    numeroGols = Column(String(150), nullable=False)
    valueUnder25 = Column(Numeric(precision=10, scale=2))
    valueOver15 = Column(Numeric(precision=10, scale=2))
    valueOver25 = Column(Numeric(precision=10, scale=2))
    valueAmbasMarcam = Column(Numeric(precision=10, scale=2))

    #RELATION
    idCompetition = Column(Integer, ForeignKey(Competition.idCompetition))    

    def toDict(self):
        return {
            'idBotTelegramRules': self.idBotTelegramRules,
            'idCompetition': self.idCompetition,
            'mercadoEntrada': self.mercadoEntrada,
            'numeroGols': self.numeroGols,
            'valueUnder25': self.valueUnder25,
            'valueOver15': self.valueOver15,
            'valueOver25': self.valueOver25,
            'valueAmbasMarcam': self.valueAmbasMarcam
        }
